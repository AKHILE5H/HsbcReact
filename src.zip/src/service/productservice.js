function search(){
        return  ( [
            { id: 'P1', name: 'Kodak', price: 20000 },
            { id: 'P2', name: 'Canon', price: 26000 },
            { id: 'P3', name: 'Sony', price: 54000 }
        ])
    }


    export let ps={'ProductService':{search}}
